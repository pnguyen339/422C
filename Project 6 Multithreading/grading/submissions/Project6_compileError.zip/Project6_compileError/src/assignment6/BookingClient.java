// Insert header here

import java.util.Map;
import java.lang.Thread;

public class BookingClient {
  public BookingClient(Map<String, Integer> office, Theater theater) {
  }

	public List<Thread> simulate() {
	}
}
