/* EE422C Project 2 (Mastermind) 
 * Peter Nguyen
 * ppn229
 * Slip days used: <0>
 * Spring 2017
 */
package assignment2;
import java.util.*;
public interface Gameplay{

	public void output(int i, String s);
	public String getUserInput(Scanner o);
	public boolean isValid(String o);


}
